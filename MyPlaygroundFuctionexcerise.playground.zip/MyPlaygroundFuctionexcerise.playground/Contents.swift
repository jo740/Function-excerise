import UIKit
var a = "10"
var B = "20"
func addTwoInts(_ a: Int, _ b: Int) -> Int {
    return a + b
}
